#include "pbcargll.h"
T_BANK_INFO        bank_info;
char	logfile[256];
 T_ICBC_GROUPHEADER icbc_groupheader;
int vSwtHUBReqBALEProcess(char *);
void QuitTerminate();
int main(int argc, char *argv[])
{
    char actno[32+1];
    char curd[3+1];
    char curdactno[35+1];
 	 short   nReturnCode;
    char    sTxnNo[CR_CLSTXNNO_LEN+1];
    int     nRet =0;
		long 	lReturn  =  0;
    /* ������ */
    if ( argc < 3 )
    {
        fprintf(stdout, "Usage: pbcargll < logfile >\n");
        exit(0);
    }


    setbuf(stdout,NULL);

    /* ������־ */
    nReturnCode = GetLogName(argv[1], logfile);
    if (nReturnCode!= 0 )
    {
        fprintf(stderr, "GetLogName error !\n");
    }
    	/*	nReturnCode = nInitMsgQue(CI_PAIDSWT, logfile);
		if (nReturnCode != 0)
		{
		}*/
	lReturn=DbConnect();
	if ( lReturn!= 0)
	{
	HtLog(HTLM_COM, "DbConnect=[%d]!\n", lReturn);
		return -1;
	}
    char api_log_file[256];
    memset(api_log_file, 0, sizeof(api_log_file));
    sprintf(api_log_file, "%s/log/pbcargll_api.log", getenv("APPL"));
   nRet = ICBC_API_INIT(api_log_file, ICBC_API_OUTSRC_SVRID);
    if (nRet != 0)
    {
    	HtLog(HTLM_ERR, "ICBC_API_INIT error(%d)", nRet);                  
        exit(1);
    }
    
    memset(&icbc_groupheader, 0, sizeof(icbc_groupheader));
    nGetICBCGroupHeader(&icbc_groupheader);
    
    memset(&bank_info, 0, sizeof(bank_info));
    nGetBankInfo(&bank_info);
    HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"cargll: Init cargll End\n");
        memset(actno,0,sizeof(actno));
    memset(curd,0,sizeof(curd));
    memset(curdactno,0,sizeof(curdactno));
	strcpy(actno, 	argv[2]);
	strcpy(curd, 	argv[3]);
  memcpy(curdactno,curd,3);
  memcpy(curdactno+3,actno,strlen(actno));
       HtLog(HTLM_COM, "curd=[%s]!\n", curd);
 		HtLog(HTLM_COM, "actno=[%s]!\n", actno);
   HtLog(HTLM_COM, "curdactno=[%s]!\n", curdactno);
    nRet = nSendBALEToICBC(&curdactno);
    if (nRet != 0)
    {
       HtLog(HTLM_COM, "Send  07 failed nRet=[%s]!\n", nRet);
        return -1;
    }
    //ȫ�����
    ICBC_API_END();
    DbDisConnect();
    HtLog(HTLM_COM, "success!\n");
    return  0;
    }
int nSendBALEToICBC(char *sActnoCurcd)
{
    int  nRet;
    int  nSendFlag;
    struct wd_pbicbcinq_area pbicbcinq_area;
    char md_time[15];
    char sId[17];
    char tmpActno[35];
    char sREFERNCE[30+1];

    memset(&pbicbcinq_area, 0, sizeof(pbicbcinq_area));
    memset(md_time, 0, sizeof(md_time));
    memset(sId, 0, sizeof(sId));
    memset(sREFERNCE, 0, sizeof(sREFERNCE));
    memset(tmpActno, 0, sizeof(tmpActno));
    nSendFlag = 0;

    RightTrim(sActnoCurcd);

    GetCurrentTimeAll(GET_CURRENT_DATE_FLAG_ICBC, md_time);
    ICBC_CALL_API_BEGIN();

    nSetICBCGroupHeader(&icbc_groupheader, md_time, ICBC_ACT_BALANCE_REQ);

    ICBC_API_SET_VALUE("api.BUSIDATE", md_time, 8);
    ICBC_API_SET_VALUE("api.SNDBNKCODE", bank_info.icbc_cnaps_code, strlen(bank_info.icbc_cnaps_code));
    //ICBC_API_SET_VALUE("api.KBIC", bank_info.icbc_cnaps_bic, strlen(bank_info.icbc_cnaps_bic));
    ICBC_API_SET_VALUE("api.ACCNO", sActnoCurcd+3, strlen(sActnoCurcd)-3);
    ICBC_API_SET_VALUE("api.CURRTYPE", sActnoCurcd, 3);

    nRet = ICBC_CALL_API("ICBC_GEN_REFERNCE");
        if(nRet != 0)
        {
            HtLog(HTLM_ERR,"ICBC_CALL_API ICBC_GEN_REFERNCE ERR=[%d]",nRet);
            return -1;
        }

    nRet = ICBC_CALL_API("OUT_MADE_ICBC_40005_REQ");
    if(nRet != 0)
    {
        HtLog(HTLM_ERR,"ICBC_CALL_API OUT_MADE_ICBC_40005_REQ failed,  return=[%d]", nRet);
        return -1;
    }

    ICBC_API_GET_VALUE("api.ID", sId, 16);
    ICBC_API_GET_VALUE("api.REFERNCE", sREFERNCE, 30);
    HtLog(HTLM_COM,"REFERNCE:[%s]",sREFERNCE);
    ICBC_CALL_API_END();
    
    /***ICBC_API_SEND֮ǰ,��Commitȷ�����ı��Ѿ�����,ICBC����ʵʱ�鵽���º������***/ 
    DbCommitTxn();
    
    T_ICBC_API_IPCMSG tIpcMsg;
    memset(&tIpcMsg, 0, sizeof(tIpcMsg));
    memcpy(tIpcMsg.sId, sId, 16);
    memcpy(tIpcMsg.sPkgNo, ICBC_ACT_BALANCE_REQ, 5);
    memcpy(tIpcMsg.sWorkDate, md_time, 8);
    tIpcMsg.cResndFlg = '0';
    nRet = ICBC_API_SEND(&tIpcMsg);
    if(nRet != 0)
    {
        HtLog(HTLM_ERR,"ICBC_API_SEND failed, id=[%s] return=[%d]",
                    sId, nRet);
        nSendFlag = 1;
    }
    strcpy(tmpActno, sActnoCurcd+3);
    RecMonitor(sId, tmpActno, ICBC_ACT_BALANCE_REQ);
    memcpy(pbicbcinq_area.id, sId, 16);
    memcpy(pbicbcinq_area.txdate, md_time, 8);
    memcpy(pbicbcinq_area.pkgtype, ICBC_ACT_BALANCE_REQ, 5);
    if(nSendFlag == 1)
    {
        pbicbcinq_area.status[0] = '2';
    }
    else
    {
        pbicbcinq_area.status[0] = '1';
    }
    memcpy(pbicbcinq_area.md_tlr, "SYS99999", sizeof(pbicbcinq_area.md_tlr )-1);
    memcpy(pbicbcinq_area.ck_tlr, "SYS99999", sizeof(pbicbcinq_area.ck_tlr )-1);
    memcpy(pbicbcinq_area.md_time, md_time, 14);
    memcpy(pbicbcinq_area.ck_time, md_time, 14);
    pbicbcinq_area.rsp_cnt = 0;
    pbicbcinq_area.rsv2[0] = 'W';

    nRet = DbsPBICBCINQ(DBS_INSERT,&pbicbcinq_area);
    if( nRet != 0 )
    {
        HtLog(HTLM_ERR, "DbsPBICBCINQ DBS_INSERT :nRet=[%d]",nRet);
        DbRollbackTxn();
        return -1;
    }
    DbCommitTxn();
    return 0;
}

