#ifndef _PB_CAR_GLL_H
#define _PB_CAR_GLL_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <time.h>
#include <signal.h>
#include <malloc.h>
#include <memory.h>
#include <assert.h>
#include <errno.h>

#include "msglog.h"
#include "swttoc.h"
#include "status.h"
#include "convert.h"
#include "wd_incl.h"
#include "glb_def.h"
#include "tivoli.h"
#include "ipc.h"
#include "htlog.h"
#include "icbc_api_def.h"
#include "icbc_api.h"
#include "icbc_api_itf.h"
#include "sysdef.h"
/* Add by ZBR 2011-08-02 START 
#include "net_smtp.h"*/
/* Add by ZBR 2011-08-02 END */

/**************��������ض���************************/
#define BAL_HEADER_RECORD_CODE      "01"            //balancefile Record Code
#define BAL_HEADER_SENDER_ID        "TOPCDROB"      //balancefile Sender Identification
#define BAL_HEADER_RECVER_ID        "IDRTOP"        //balancefile Receiver Identification
#define BAL_HEADER_RECORD_LEN       "80"            //balancefile Physical Record Length
#define BAL_HEADER_VERSION_NUM      "2"             //balancefile Version Number
                                                    
#define BAL_GHEADER_RECORD_CODE     "02"            //balancefile group Record Code
#define BAL_GHEADER_ORIG_ID         "ICBKCNBJXXX��"  //balancefile group Originator Identification     

#define BAL_BODY_RECORD_CODE        "03"            //balancefile body Record Code
#define BAL_TYPE_CODE_CLB           "015"           //balancefile body Closing Ledger Balance
#define BAL_TYPE_CODE_OAB           "040"           //balancefile body Opening Available Balance

#define BAL_BODY_TAIL_RECORD_CODE   "49"            //balancefile body tail Record Code
#define BAL_GTAIL_RECORD_CODE       "98"            //balancefile group tail Record Code
#define BAL_TAIL_RECORD_CODE        "99"            //balancefile tail Record Code


/****************************************************/

#endif

