#!/bin/bash

STARTTIME=$1

echo "$STARTTIME"
#STARTTIME=163500

LOGFILE=./checkrcv.log
MAIL_TO=zhang1141754887@126.com


GETDATA(){
sqlplus -s ${DBUSER}/${DBPWD}@${TNS_NAME}<< EOF >/dev/null
set heading off;
set term off;
set echo off;
set pagesize 0;
set linesize 1500;
set trimspool on;
set trimout on;
set feedback off;
set colsep |;
spool ./rcvdata.txt
select a.accno,b.name,a.balance from icbc_40005_rsp_txn a,pbcustctl b
where a.accno=b.actno and a.txdate='$SYS_DATE' and a.rsv1='W';
spool off;
EOF
count1=`wc -l rcvdata.txt|awk '{print $1}'`
}


GETWORKDATE(){
sqlplus -s ${DBUSER}/${DBPWD}@${TNS_NAME}<< EOF >/dev/null
set heading off;
set term off;
set echo off;
set pagesize 0;
set linesize 1500;
set trimspool on;
set trimout on;
set feedback off;
set colsep |;
spool ./workdate.txt
select * from pbholiday
where Hdate='$SYS_DATE' and work='1';
spool off;
EOF
count=`wc -l workdate.txt|awk '{print $1}'`
}


main(){
while true
do

SYS_DATE=`date '+%Y%m%d'`
SYS_TIME=`date '+%Y-%m-%d %H:%M:%S'`
current_time=`date '+%H%M%S'`

if [ $current_time -eq $STARTTIME ]
then
  GETWORKDATE
  echo "2222222222222"
if [ $count -eq 0 ]
then
  echo "[$SYS_DATE]:--------------not work date---------------" >>$LOGFILE
  sleep 82800
continue
fi


ACCNODATE=""
for ACCNODATE in `cat accno.txt`
do
pbcargll pbcargill.log $ACCNODATE CNY >>$LOGFILE
done
sleep 60

echo "33333333333333"
GETDATA
echo "44444444444444444"
if [ $count1 -eq 0 ]
then
  echo "[$SYS_DATE]:888888888888888888888" >> $LOGFILE
	echo -e "$SYS_DATE 789"| mail -s "233" $MAIL_TO>> $LOGFILE
	echo "[$SYS_DATE]:999999999999999999999" >> $LOGFILE
	echo "------not data-----------" >> $LOGFILE
else
	RCVDATA=""
	RCVDATA=`cat rcvdata.txt`
  echo "[$SYS_DATE]:66666666666666666666" >> $LOGFILE
	echo -e "$SYS_DATE 123"| mail -s "456" $MAIL_TO>> $LOGFILE
	 echo "[$SYS_DATE]:777777777777777777777" >> $LOGFILE
	echo "------have data----------" >> $LOGFILE
	echo "[$SYS_DATE]:5555555555555555555" >> $LOGFILE
fi
fi
sleep 1
done
}
main
